"""
Compare all dimensionality reduction methods on ERP EEG data.
Run: python compare_methods.py
"""
import os, random, warnings, logging
import numpy as np
import pandas as pd
from plotnine import (ggplot, aes, geom_point, facet_wrap,
                      theme_bw, theme, labs, scale_color_cmap,
                      element_blank, element_text, ggsave)
from plotnine.scales import scale_color_brewer
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import cross_val_score
from scipy.spatial.distance import pdist, squareform
from scipy.stats import pearsonr
import umap, phate, tphate
import tensorflow as tf
from tensorflow.keras.models import load_model

from recursiveBCN_utils import create_kl_divergence
from data_preprocess import erp_data_preprocess

tf.config.experimental_run_functions_eagerly(True)
warnings.filterwarnings("ignore")
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
logging.getLogger('absl').setLevel(logging.ERROR)

SEED    = 42
BALANCE = 4
np.random.seed(SEED); random.seed(SEED)


# Metrics functions

def knn_acc(emb, labels_cond, n_tp, k=5):
    labels_full = np.repeat(labels_cond, n_tp)
    cv = min(5, len(labels_full) // len(np.unique(labels_full)))
    return float(np.mean(cross_val_score(
        KNeighborsClassifier(n_neighbors=k), emb, labels_full, cv=cv)))

#adapted from rsa, but for timepoints 
def temporal_rsa(emb, X_high, n_groups, n_tp):
    scores = []
    for g in range(n_groups):
        sl = slice(g * n_tp, (g + 1) * n_tp)
        scores.append(pearsonr(
            squareform(pdist(X_high[sl])).flatten(),
            squareform(pdist(emb[sl])).flatten())[0])
    return float(np.mean(scores))

def trustworthiness_continuity(dist_orig, dist_embed, n_neighbors=5):
    n = dist_orig.shape[0]
    rank_orig  = np.argsort(np.argsort(dist_orig,  axis=1), axis=1)
    rank_embed = np.argsort(np.argsort(dist_embed, axis=1), axis=1)
    t_sum = c_sum = 0.0
    for i in range(n):
        #Neighbors in the original space
        orig_nb  = set(np.where(rank_orig[i]  < n_neighbors)[0])
        #Neighbors in the embedded space
        embed_nb = set(np.where(rank_embed[i] < n_neighbors)[0])
        for j in (embed_nb - orig_nb):  t_sum += rank_orig[i, j]  - n_neighbors
        for j in (orig_nb - embed_nb):  c_sum += rank_embed[i, j] - n_neighbors
    norm = 2 * (n * n_neighbors * (2*n - 3*n_neighbors - 1))
    return float(1 - t_sum / norm), float(1 - c_sum / norm)


#helper functions
def find_latest_bcne_dir():
    base = 'results'
    runs = sorted(os.listdir(base), key=lambda d: os.path.getmtime(os.path.join(base, d)))
    return os.path.join(base, runs[-1]) if runs else None

# data loading for PCA, tsne, umap, phate, tphate methods (no TimeCORR/NeuroMap) 
def load_raw_flat(csv_path, cond_names):
    df   = pd.read_csv(csv_path)
    meta = ['Time_ms', 'Trial_ID', 'Condition', 'Continuous']
    chs  = [c for c in df.columns if c not in meta]
    tm   = df.groupby('Trial_ID').first()[['Condition', 'Continuous']].reset_index()
    ci   = {c: i for i, c in enumerate(cond_names)}
    keys = sorted(tm.groupby(['Condition', 'Continuous']).groups.keys(), key=lambda x: (ci[x[0]], x[1]))
    grps = tm.groupby(['Condition', 'Continuous']).groups
    blocks = [np.mean([df[df['Trial_ID']==tid].sort_values('Time_ms')[chs].values
                       for tid in tm.loc[grps[k].tolist(), 'Trial_ID'].values], axis=0) for k in keys]
    X = np.concatenate(blocks, axis=0)
    return (X - X.min()) / (X.max() - X.min())

METHOD_ORDER = ['PCA', 't-SNE', 'UMAP', 'PHATE', 'T-PHATE', 'BCNE m1', 'BCNE m4']

#stack all embeddings into a single dataframe for plotting with plotnine
def build_df(embeddings, labels_cond, labels_cont, cond_names, n_tp):
    n_groups        = len(labels_cond)
    cond_labels_str = [cond_names[c] for c in labels_cond]
    df = pd.concat([
        pd.DataFrame({
            'x':          emb[:, 0],
            'y':          emb[:, 1],
            'method':     name,
            'condition':  np.repeat(labels_cond, n_tp),
            'cond_name':  np.repeat(cond_labels_str, n_tp),
            'continuous': np.repeat(labels_cont, n_tp),
            'time':       np.tile(np.arange(n_tp), n_groups),
        })
        for name, emb in embeddings.items()
    ], ignore_index=True)
    order = [m for m in METHOD_ORDER if m in df['method'].unique()]
    df['method'] = pd.Categorical(df['method'], categories=order, ordered=True)
    return df


#Plotting
def scatter_fig(df, hue, title, path, col_wrap=4):
    if hue == 'time':
        color_scale = scale_color_cmap('plasma')
    elif hue == 'continuous':
        color_scale = scale_color_cmap('viridis')
    else:
        color_scale = scale_color_brewer(type='qual', palette='Set1')

    n_methods = df['method'].nunique()
    p = (ggplot(df, aes('x', 'y', color=hue))
         + geom_point(size=0.4, alpha=0.8)
         + facet_wrap('method', ncol=col_wrap, scales='free')
         + color_scale
         + labs(title=title, x='', y='')
         + theme_bw()
         + theme(
             axis_text_x        = element_blank(),
             axis_text_y        = element_blank(),
             axis_ticks_major_x = element_blank(),
             axis_ticks_major_y = element_blank(),
             axis_title         = element_blank(),
             panel_grid         = element_blank(),
             plot_title         = element_text(size=14, face='bold', ha='center'),
             strip_text         = element_text(size=10, face='bold'),
             strip_background   = element_blank(),
             figure_size        = (3 * col_wrap, 3 * -(-n_methods // col_wrap)),
             subplots_adjust    = {'top': 0.92, 'hspace': 0.3, 'wspace': 0.1},
         ))
    ggsave(p, path, dpi=250, bbox_inches='tight')
    print(f"Saved: {os.path.basename(path)}")
    
#erp waveform at Fz channel as sanity check
def erp_waveform_fig(csv_path, cont_vals, cond_names, path):
    df   = pd.read_csv(csv_path)
    meta = ['Time_ms', 'Trial_ID', 'Condition', 'Continuous']
    ch   = next((c for c in df.columns if c == 'Fz'), [c for c in df.columns if c not in meta][0])
    norm = plt.Normalize(cont_vals.min(), cont_vals.max())
    PEAKS = {'P100': 100, 'N170': 170, 'P300': 300, 'N400': 400}

    fig, axes = plt.subplots(1, len(cond_names), figsize=(6 * len(cond_names), 4), sharey=True)
    axes = [axes] if len(cond_names) == 1 else list(axes)
    all_vals = []

    for ax, cond in zip(axes, cond_names):
        sub   = df[df['Condition'] == cond]
        times = sub.groupby('Time_ms')[ch].mean().index.values
        for cont, grp in sub.groupby('Continuous'):
            avg = grp.sort_values('Time_ms').groupby('Time_ms')[ch].mean().values
            all_vals.extend(avg); ax.plot(times, avg, color=plt.cm.viridis(norm(cont)), lw=1.5, alpha=0.85)
        ax.axhline(0, color='gray', lw=0.6, ls='--', alpha=0.5)
        y_top = max(all_vals) * 0.92
        for pname, t in PEAKS.items():
            if t <= times.max():
                ax.axvline(t, color='gray', lw=0.8, ls=':', alpha=0.4)
                ax.text(t, y_top, pname, fontsize=8, ha='center', color='dimgray')
        ax.set_title(str(cond).capitalize(), fontweight='bold', fontsize=13)
        ax.set_xlabel('Time (ms)'); ax.spines[['top', 'right']].set_visible(False)

    axes[0].set_ylabel('Amplitude (µV)')
    fig.suptitle('ERP Waveforms by Continuous Level', fontsize=14, fontweight='bold')
    plt.tight_layout()
    sm = plt.cm.ScalarMappable(cmap='viridis', norm=norm); sm.set_array([])
    fig.colorbar(sm, cax=fig.add_axes([1.01, 0.15, 0.015, 0.7])).set_label('Continuous')
    fig.savefig(path, dpi=250, bbox_inches='tight', facecolor='white'); plt.close()
    print(f"Saved: {os.path.basename(path)}")


#Main
def main():
    bcne_dir = find_latest_bcne_dir()
    if bcne_dir is None:
        print("ERROR: No results found in results/. Run main.py first.")
        return

    csv_path = open(f'{bcne_dir}/csv_path.txt').read().strip()
    out      = f'{bcne_dir}/comparison'
    os.makedirs(out, exist_ok=True)
    print(f"BCNE dir : {bcne_dir}\nCSV      : {csv_path}\nOutput   : {out}")

    # Load data
    X_full, labels_cond, labels_cont, n, n_tp, cond_names, _ = erp_data_preprocess(csv_path)
    X_flat = load_raw_flat(csv_path, cond_names)
    n_groups = len(labels_cond)
    print(f"Groups: {n_groups} | Conditions: {cond_names} | Timepoints: {n_tp}")

    # Load BCNE embeddings
    kl        = create_kl_divergence(n // BALANCE, 2)
    bcne_embs = {}
    for m in [1, 2, 3, 4]:
        p = f'{bcne_dir}/m{m}.h5'
        if os.path.exists(p):
            bcne_embs[f'BCNE m{m}'] = load_model(
                p, custom_objects={'KLdivergence': kl}).predict(X_full, verbose=0)
            print(f"  BCNE m{m}: loaded")

    # Compare methods
    print("\nRunning all methods...")
    embeddings = {
        'PCA':     PCA(2, random_state=SEED).fit_transform(X_flat),
        't-SNE':   TSNE(2, random_state=SEED, n_jobs=-1).fit_transform(X_flat),
        'UMAP':    umap.UMAP(2, random_state=SEED, n_jobs=-1).fit_transform(X_flat),
        'PHATE':   phate.PHATE(2, knn=5, decay=40, n_jobs=-1, verbose=0,
                               random_state=SEED).fit_transform(X_flat),
        'T-PHATE': tphate.TPHATE(2, knn=5, decay=40, n_jobs=-1, verbose=0,
                                  random_state=SEED).fit_transform(X_flat),
        **{k: v for k, v in bcne_embs.items() if k in ('BCNE m1', 'BCNE m4')},
    }
    print("Comparison done.")

    # Metrics
    print("\nComputing metrics...")
    D_high  = squareform(pdist(X_flat))
    results = {}
    for name, emb in embeddings.items():
        D_emb = squareform(pdist(emb))
        t, c  = trustworthiness_continuity(D_high, D_emb)
        results[name] = {
            'KNN':             knn_acc(emb, labels_cond, n_tp),
            'RSA':             temporal_rsa(emb, X_flat, n_groups, n_tp),
            'Trustworthiness': t,
            'Continuity':      c,
        }
        print(f"  {name:15s}  KNN={results[name]['KNN']:.3f}  RSA={results[name]['RSA']:.3f}"
              f"  T={t:.3f}  C={c:.3f}")
    pd.DataFrame(results).T.to_csv(f'{out}/comparison_metrics.csv')
    print("Saved: comparison_metrics.csv")

    # Figures
    erp_waveform_fig(csv_path, labels_cont, cond_names, f'{out}/fig1_erp_waveforms.png')

    df = build_df(embeddings, labels_cond, labels_cont, cond_names, n_tp)
    scatter_fig(df, 'cond_name', 'Condition Separation',   f'{out}/fig2_condition.png')
    for cond_int, cond_name in enumerate(cond_names):
        scatter_fig(df[df.condition == cond_int], 'time',
                    f'Temporal — {cond_name.capitalize()}',
                    f'{out}/fig3_time_{cond_name}.png')
    scatter_fig(df, 'continuous', 'Continuous Gradient',   f'{out}/fig5_continuous.png')

    print(f"\nDone. All figures saved to: {out}/")


if __name__ == "__main__":
    main()
