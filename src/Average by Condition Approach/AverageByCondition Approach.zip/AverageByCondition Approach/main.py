import numpy as np
from train_model import main_erp

np.seterr(divide='ignore', invalid='ignore')

CSV_PATH = 'data/4conditions_noise1.csv'

if __name__ == "__main__":
    main_erp(
        n_components=2, recur=4, balance=4,
        csv_path=CSV_PATH,
    )
