"""
Training pipeline for ERP EEG BCNE model.
"""
import os, warnings, random
import numpy as np
from datetime import datetime

warnings.filterwarnings('ignore')
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'

import logging
logging.getLogger('absl').setLevel(logging.ERROR)

import tensorflow as tf
from tensorflow.keras.models import load_model
from tensorflow.keras.optimizers import Adam
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

from data_preprocess import erp_data_preprocess
from recursiveBCN_utils import (create_model, create_kl_divergence,
                                 train_model_with_patient,
                                 calculate_low_para_for_input,
                                 calculate_low_para_for_layer)

random.seed(0); np.random.seed(0)
tf.config.experimental_run_functions_eagerly(True)

EPOCHS  = 200
PATIENT = 20
HD_TYPE = 'erp'

# (stage_label, P_source_function)
_STAGES = [
    ("Input",  lambda m, X, n, bs, hd: calculate_low_para_for_input(m, X, n, bs, hd)),
    ("Dense1", lambda m, X, n, bs, hd: calculate_low_para_for_layer(m, X, 'Dense1', n, bs, hd)),
    ("Dense2", lambda m, X, n, bs, hd: calculate_low_para_for_layer(m, X, 'Dense2', n, bs, hd)),
    ("Dense3", lambda m, X, n, bs, hd: calculate_low_para_for_layer(m, X, 'Dense3', n, bs, hd)),
]

# plot output after each training stage
def plot_stage(model, X_train, labels_cond, labels_cont, cond_names,
               n_tp, out_path, stage_num, csv_path):
    pred             = model.predict(X_train, verbose=0)
    labels_cond_full = np.repeat(labels_cond, n_tp)
    labels_cont_full = np.repeat(labels_cont, n_tp)

    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    cmap = plt.get_cmap('tab10')
    for i, name in enumerate(cond_names):
        mask = labels_cond_full == i
        axes[0].scatter(pred[mask, 0], pred[mask, 1],
                        c=[cmap(i)], s=8, alpha=0.4, label=name.capitalize())
    axes[0].set_title(f'm{stage_num} - Condition', fontweight='bold')
    axes[0].legend(fontsize=9)

    sc = axes[1].scatter(pred[:, 0], pred[:, 1], c=labels_cont_full, cmap='viridis', s=8, alpha=0.4)
    axes[1].set_title(f'm{stage_num} - Continuous', fontweight='bold')
    plt.colorbar(sc, ax=axes[1], fraction=0.046)

    fig.suptitle(f'BCNE m{stage_num} — {os.path.basename(csv_path)}', fontsize=12, fontweight='bold')
    plt.tight_layout()
    plt.savefig(out_path, dpi=120, bbox_inches='tight', facecolor='white')
    plt.close()
    print(f"  Stage m{stage_num} plot saved: {out_path}")

#Train BCNE on ERP EEG data on unique groups defined by condition and continuous levels, with trial averaging and TimeCORR+NeuroMap preprocessing
def main_erp(n_components=2, recur=4, balance=4,
             csv_path='data/DR_8April.csv',
             output_dir=None):
    model_design = [4, [3, 16, 32, 64], (1024, 512, 256, 8), n_components]

    if output_dir is None:
        output_dir = f'results/{datetime.now().strftime("%Y-%m-%d_%H-%M-%S")}'
    os.makedirs(output_dir, exist_ok=True)
    with open(f'{output_dir}/csv_path.txt', 'w') as f:
        f.write(csv_path)

    X_train_proj, labels_cond, labels_cont, n, n_tp, cond_names, grid = erp_data_preprocess(csv_path)

    print(f"\n{'='*60}")
    #print number of groups, conditions, and recursion stages
    print(f"ERP Training — {len(labels_cond)} groups, {len(cond_names)} conditions, recur={recur}")
    print(f"Conditions : {cond_names}  |  Grid: {grid}×{grid}")
    print(f"Results    : {output_dir}")
    print(f"{'='*60}")

    batch_size = n // balance
    model = create_model(
        input_shape     = (grid, grid, 1),
        num_conv_layers = model_design[0],
        filters_list    = model_design[1],
        kernel_size     = 3,
        alpha           = 0.05,
        dense_units     = model_design[2],
        final_units     = model_design[3],
    )
    kl_loss = create_kl_divergence(batch_size, n_components)
    model.compile(loss=kl_loss, optimizer=Adam(learning_rate=0.0005))
    print(f"  Model parameters: {model.count_params():,}")

    out_paths = [f'{output_dir}/m{i}.h5' for i in range(1, recur + 1)]

    for i, (label, p_func) in enumerate(_STAGES[:recur]):
        if i > 0:
            model = load_model(out_paths[i - 1], custom_objects={'KLdivergence': kl_loss})
            model.compile(loss=kl_loss, optimizer=Adam(learning_rate=0.0005))
        print(f"\n  ── Recursion {i+1} ({label}) ──")
        model = train_model_with_patient(
            model, X_train_proj, out_paths[i],
            p_func, EPOCHS, PATIENT, n, batch_size, HD_TYPE)
        plot_stage(model, X_train_proj, labels_cond, labels_cont, cond_names,
                   n_tp, f'{output_dir}/m{i+1}.png', i+1, csv_path)

    print(f"\n  Training complete! Models saved in: {output_dir}")
    return model, output_dir  #Returns the final trained model (stage 4) and the output folder
