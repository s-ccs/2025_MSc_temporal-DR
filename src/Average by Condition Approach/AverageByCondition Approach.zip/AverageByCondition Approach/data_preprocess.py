import numpy as np
import pandas as pd
from temporal_pro import TimeCORR
from sklearn.feature_selection import VarianceThreshold
from spatial_pro import construct_neuromap


def erp_data_preprocess(csv_path):
    """
    Load and preprocess ERP data: TimeCORR + NeuroMap → (N, grid, grid, 1).
    Grid size is the smallest square that fits all channels (e.g. 32ch → 6×6).
    Works with any number of conditions, continuous levels, and channels.
    """
    df = pd.read_csv(csv_path)
    meta_cols = ['Time_ms', 'Trial_ID', 'Condition', 'Continuous']
    channel_cols = [c for c in df.columns if c not in meta_cols]
    n_timepoints = df[df['Trial_ID'] == df['Trial_ID'].iloc[0]].shape[0]

    # smallest square grid that fits all channels: ceil(sqrt(n_channels))
    n_channels = len(channel_cols)
    grid = int(np.ceil(np.sqrt(n_channels)))  # 32ch→6, 64ch→8, 128ch→12

    trial_meta = df.groupby('Trial_ID').first()[['Condition', 'Continuous']].reset_index()

    cond_names = sorted(trial_meta['Condition'].unique())
    cond_to_int = {c: i for i, c in enumerate(cond_names)}
    groups = trial_meta.groupby(['Condition', 'Continuous']).groups
    sorted_keys = sorted(groups.keys(), key=lambda x: (cond_to_int[x[0]], x[1]))
    labels_condition, labels_continuous, data_all = [], [], []
    
#select unique groups and averages trials within each group
    for cond, cont in sorted_keys:
        trial_id_vals = trial_meta.loc[groups[(cond, cont)].tolist(), 'Trial_ID'].values  #group trial ids
        trial_data_list = [
            df[df['Trial_ID'] == tid].sort_values('Time_ms')[channel_cols].values
            for tid in trial_id_vals
        ]
        X = np.mean(trial_data_list, axis=0)  # average over trials for each group

        autocorr_map = TimeCORR(X=X, smooth_window=1)  #time correlation
        X = np.matmul(autocorr_map, X)
        nump = grid * grid
        if nump < X.shape[1]:
            selector = VarianceThreshold()
            top_n = selector.fit(X).get_support(indices=True)
            X = X[:, top_n[:nump]]
        X = construct_neuromap(X, grid, grid, epsilon=0.0, num_iter=200)  # create images by placing channels on grid for CNN

        data_all.append(X)
        labels_condition.append(cond_to_int[cond])
        labels_continuous.append(cont)

    X_out = np.concatenate(data_all, axis=0)
    labels_condition = np.array(labels_condition)
    labels_continuous = np.array(labels_continuous)

    xmin, xmax = X_out.min(), X_out.max()
    X_out = (X_out - xmin) / (xmax - xmin)

    return X_out, labels_condition, labels_continuous, X_out.shape[0], n_timepoints, cond_names, grid
